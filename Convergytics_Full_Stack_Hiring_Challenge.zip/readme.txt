frontend:
1. open terminal run ng serve
2. browser: localhost:4200

backend:
1. update db.js with your db credentials
2. seed function will populate as soon as you run node server.js

due to less time, was able to finish every task in plus points

Sunny Setia