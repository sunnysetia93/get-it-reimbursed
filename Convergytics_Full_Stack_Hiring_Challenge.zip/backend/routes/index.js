var router = require('express').Router();

router.use('/expense',require('./expense.js'))


module.exports = router
